/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0xc3576ebc */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static const char *ng0 = "//windows/usuarios/NDisco/ins/francisco.cedron/STR/p2/p2.vhd";
extern char *IEEE_P_2592010699;
extern char *IEEE_P_3620187407;

unsigned char ieee_p_2592010699_sub_1605435078_503743352(char *, unsigned char , unsigned char );
char *ieee_p_2592010699_sub_1697423399_503743352(char *, char *, char *, char *, char *, char *);
char *ieee_p_2592010699_sub_1735675855_503743352(char *, char *, char *, char *, char *, char *);
char *ieee_p_2592010699_sub_1837678034_503743352(char *, char *, char *, char *);
char *ieee_p_2592010699_sub_795620321_503743352(char *, char *, char *, char *, char *, char *);
char *ieee_p_3620187407_sub_767668596_3965413181(char *, char *, char *, char *, char *, char *);
char *ieee_p_3620187407_sub_767740470_3965413181(char *, char *, char *, char *, char *, char *);


static void work_a_0328778702_3212880686_p_0(char *t0)
{
    char t30[16];
    char t46[16];
    unsigned char t1;
    char *t2;
    unsigned char t3;
    char *t4;
    char *t5;
    unsigned char t6;
    unsigned char t7;
    char *t8;
    char *t9;
    char *t10;
    char *t11;
    int t12;
    int t13;
    int t14;
    char *t15;
    char *t16;
    int t17;
    char *t18;
    char *t19;
    int t20;
    char *t21;
    int t23;
    char *t24;
    int t26;
    char *t27;
    int t29;
    char *t31;
    char *t32;
    char *t33;
    char *t34;
    unsigned int t35;
    unsigned int t36;
    char *t37;
    char *t38;
    char *t39;
    char *t40;
    char *t41;
    unsigned int t42;
    unsigned int t43;
    unsigned int t44;
    unsigned int t45;

LAB0:    xsi_set_current_line(59, ng0);
    t2 = (t0 + 1792U);
    t3 = xsi_signal_has_event(t2);
    if (t3 == 1)
        goto LAB5;

LAB6:    t1 = (unsigned char)0;

LAB7:    if (t1 != 0)
        goto LAB2;

LAB4:
LAB3:    t2 = (t0 + 3312);
    *((int *)t2) = 1;

LAB1:    return;
LAB2:    xsi_set_current_line(60, ng0);
    t4 = (t0 + 3392);
    t8 = (t4 + 56U);
    t9 = *((char **)t8);
    t10 = (t9 + 56U);
    t11 = *((char **)t10);
    *((unsigned char *)t11) = (unsigned char)2;
    xsi_driver_first_trans_fast_port(t4);
    xsi_set_current_line(61, ng0);
    t2 = (t0 + 1352U);
    t4 = *((char **)t2);
    t2 = (t0 + 5436);
    t12 = xsi_mem_cmp(t2, t4, 3U);
    if (t12 == 1)
        goto LAB9;

LAB18:    t8 = (t0 + 5439);
    t13 = xsi_mem_cmp(t8, t4, 3U);
    if (t13 == 1)
        goto LAB10;

LAB19:    t10 = (t0 + 5442);
    t14 = xsi_mem_cmp(t10, t4, 3U);
    if (t14 == 1)
        goto LAB11;

LAB20:    t15 = (t0 + 5445);
    t17 = xsi_mem_cmp(t15, t4, 3U);
    if (t17 == 1)
        goto LAB12;

LAB21:    t18 = (t0 + 5448);
    t20 = xsi_mem_cmp(t18, t4, 3U);
    if (t20 == 1)
        goto LAB13;

LAB22:    t21 = (t0 + 5451);
    t23 = xsi_mem_cmp(t21, t4, 3U);
    if (t23 == 1)
        goto LAB14;

LAB23:    t24 = (t0 + 5454);
    t26 = xsi_mem_cmp(t24, t4, 3U);
    if (t26 == 1)
        goto LAB15;

LAB24:    t27 = (t0 + 5457);
    t29 = xsi_mem_cmp(t27, t4, 3U);
    if (t29 == 1)
        goto LAB16;

LAB25:
LAB17:    xsi_set_current_line(80, ng0);
    t2 = (t0 + 1032U);
    t4 = *((char **)t2);
    t2 = (t0 + 3456);
    t5 = (t2 + 56U);
    t8 = *((char **)t5);
    t9 = (t8 + 56U);
    t10 = *((char **)t9);
    memcpy(t10, t4, 4U);
    xsi_driver_first_trans_fast_port(t2);

LAB8:    goto LAB3;

LAB5:    t4 = (t0 + 1832U);
    t5 = *((char **)t4);
    t6 = *((unsigned char *)t5);
    t7 = (t6 == (unsigned char)2);
    t1 = t7;
    goto LAB7;

LAB9:    xsi_set_current_line(63, ng0);
    t31 = (t0 + 1032U);
    t32 = *((char **)t31);
    t31 = (t0 + 5352U);
    t33 = ieee_p_2592010699_sub_1837678034_503743352(IEEE_P_2592010699, t30, t32, t31);
    t34 = (t30 + 12U);
    t35 = *((unsigned int *)t34);
    t36 = (1U * t35);
    t1 = (4U != t36);
    if (t1 == 1)
        goto LAB27;

LAB28:    t37 = (t0 + 3456);
    t38 = (t37 + 56U);
    t39 = *((char **)t38);
    t40 = (t39 + 56U);
    t41 = *((char **)t40);
    memcpy(t41, t33, 4U);
    xsi_driver_first_trans_fast_port(t37);
    goto LAB8;

LAB10:    xsi_set_current_line(65, ng0);
    t2 = (t0 + 1032U);
    t4 = *((char **)t2);
    t2 = (t0 + 5352U);
    t5 = (t0 + 1192U);
    t8 = *((char **)t5);
    t5 = (t0 + 5368U);
    t9 = ieee_p_2592010699_sub_795620321_503743352(IEEE_P_2592010699, t30, t4, t2, t8, t5);
    t10 = (t30 + 12U);
    t35 = *((unsigned int *)t10);
    t36 = (1U * t35);
    t1 = (4U != t36);
    if (t1 == 1)
        goto LAB29;

LAB30:    t11 = (t0 + 3456);
    t15 = (t11 + 56U);
    t16 = *((char **)t15);
    t18 = (t16 + 56U);
    t19 = *((char **)t18);
    memcpy(t19, t9, 4U);
    xsi_driver_first_trans_fast_port(t11);
    goto LAB8;

LAB11:    xsi_set_current_line(67, ng0);
    t2 = (t0 + 1032U);
    t4 = *((char **)t2);
    t2 = (t0 + 5352U);
    t5 = (t0 + 1192U);
    t8 = *((char **)t5);
    t5 = (t0 + 5368U);
    t9 = ieee_p_2592010699_sub_1735675855_503743352(IEEE_P_2592010699, t30, t4, t2, t8, t5);
    t10 = (t30 + 12U);
    t35 = *((unsigned int *)t10);
    t36 = (1U * t35);
    t1 = (4U != t36);
    if (t1 == 1)
        goto LAB31;

LAB32:    t11 = (t0 + 3456);
    t15 = (t11 + 56U);
    t16 = *((char **)t15);
    t18 = (t16 + 56U);
    t19 = *((char **)t18);
    memcpy(t19, t9, 4U);
    xsi_driver_first_trans_fast_port(t11);
    goto LAB8;

LAB12:    xsi_set_current_line(69, ng0);
    t2 = (t0 + 1032U);
    t4 = *((char **)t2);
    t2 = (t0 + 5352U);
    t5 = (t0 + 1192U);
    t8 = *((char **)t5);
    t5 = (t0 + 5368U);
    t9 = ieee_p_2592010699_sub_1697423399_503743352(IEEE_P_2592010699, t30, t4, t2, t8, t5);
    t10 = (t30 + 12U);
    t35 = *((unsigned int *)t10);
    t36 = (1U * t35);
    t1 = (4U != t36);
    if (t1 == 1)
        goto LAB33;

LAB34:    t11 = (t0 + 3456);
    t15 = (t11 + 56U);
    t16 = *((char **)t15);
    t18 = (t16 + 56U);
    t19 = *((char **)t18);
    memcpy(t19, t9, 4U);
    xsi_driver_first_trans_fast_port(t11);
    goto LAB8;

LAB13:    xsi_set_current_line(71, ng0);
    t2 = (t0 + 1032U);
    t4 = *((char **)t2);
    t2 = (t0 + 5352U);
    t5 = (t0 + 1192U);
    t8 = *((char **)t5);
    t5 = (t0 + 5368U);
    t9 = ieee_p_3620187407_sub_767668596_3965413181(IEEE_P_3620187407, t30, t4, t2, t8, t5);
    t10 = (t30 + 12U);
    t35 = *((unsigned int *)t10);
    t36 = (1U * t35);
    t1 = (4U != t36);
    if (t1 == 1)
        goto LAB35;

LAB36:    t11 = (t0 + 3456);
    t15 = (t11 + 56U);
    t16 = *((char **)t15);
    t18 = (t16 + 56U);
    t19 = *((char **)t18);
    memcpy(t19, t9, 4U);
    xsi_driver_first_trans_fast_port(t11);
    xsi_set_current_line(72, ng0);
    t2 = (t0 + 1032U);
    t4 = *((char **)t2);
    t12 = (3 - 3);
    t35 = (t12 * -1);
    t36 = (1U * t35);
    t42 = (0 + t36);
    t2 = (t4 + t42);
    t1 = *((unsigned char *)t2);
    t5 = (t0 + 1192U);
    t8 = *((char **)t5);
    t13 = (3 - 3);
    t43 = (t13 * -1);
    t44 = (1U * t43);
    t45 = (0 + t44);
    t5 = (t8 + t45);
    t3 = *((unsigned char *)t5);
    t6 = ieee_p_2592010699_sub_1605435078_503743352(IEEE_P_2592010699, t1, t3);
    t9 = (t0 + 3392);
    t10 = (t9 + 56U);
    t11 = *((char **)t10);
    t15 = (t11 + 56U);
    t16 = *((char **)t15);
    *((unsigned char *)t16) = t6;
    xsi_driver_first_trans_fast_port(t9);
    goto LAB8;

LAB14:    xsi_set_current_line(74, ng0);
    t2 = (t0 + 1032U);
    t4 = *((char **)t2);
    t2 = (t0 + 5352U);
    t5 = (t0 + 1192U);
    t8 = *((char **)t5);
    t5 = (t0 + 5368U);
    t9 = ieee_p_3620187407_sub_767740470_3965413181(IEEE_P_3620187407, t30, t4, t2, t8, t5);
    t10 = (t30 + 12U);
    t35 = *((unsigned int *)t10);
    t36 = (1U * t35);
    t1 = (4U != t36);
    if (t1 == 1)
        goto LAB37;

LAB38:    t11 = (t0 + 3456);
    t15 = (t11 + 56U);
    t16 = *((char **)t15);
    t18 = (t16 + 56U);
    t19 = *((char **)t18);
    memcpy(t19, t9, 4U);
    xsi_driver_first_trans_fast_port(t11);
    goto LAB8;

LAB15:    xsi_set_current_line(76, ng0);
    t2 = (t0 + 1032U);
    t4 = *((char **)t2);
    t35 = (3 - 2);
    t36 = (t35 * 1U);
    t42 = (0 + t36);
    t2 = (t4 + t42);
    t8 = ((IEEE_P_2592010699) + 4024);
    t9 = (t46 + 0U);
    t10 = (t9 + 0U);
    *((int *)t10) = 2;
    t10 = (t9 + 4U);
    *((int *)t10) = 0;
    t10 = (t9 + 8U);
    *((int *)t10) = -1;
    t12 = (0 - 2);
    t43 = (t12 * -1);
    t43 = (t43 + 1);
    t10 = (t9 + 12U);
    *((unsigned int *)t10) = t43;
    t5 = xsi_base_array_concat(t5, t30, t8, (char)97, t2, t46, (char)99, (unsigned char)2, (char)101);
    t43 = (3U + 1U);
    t1 = (4U != t43);
    if (t1 == 1)
        goto LAB39;

LAB40:    t10 = (t0 + 3456);
    t11 = (t10 + 56U);
    t15 = *((char **)t11);
    t16 = (t15 + 56U);
    t18 = *((char **)t16);
    memcpy(t18, t5, 4U);
    xsi_driver_first_trans_fast_port(t10);
    goto LAB8;

LAB16:    xsi_set_current_line(78, ng0);
    t2 = (t0 + 1032U);
    t4 = *((char **)t2);
    t35 = (3 - 3);
    t36 = (t35 * 1U);
    t42 = (0 + t36);
    t2 = (t4 + t42);
    t8 = ((IEEE_P_2592010699) + 4024);
    t9 = (t46 + 0U);
    t10 = (t9 + 0U);
    *((int *)t10) = 3;
    t10 = (t9 + 4U);
    *((int *)t10) = 1;
    t10 = (t9 + 8U);
    *((int *)t10) = -1;
    t12 = (1 - 3);
    t43 = (t12 * -1);
    t43 = (t43 + 1);
    t10 = (t9 + 12U);
    *((unsigned int *)t10) = t43;
    t5 = xsi_base_array_concat(t5, t30, t8, (char)99, (unsigned char)2, (char)97, t2, t46, (char)101);
    t43 = (1U + 3U);
    t1 = (4U != t43);
    if (t1 == 1)
        goto LAB41;

LAB42:    t10 = (t0 + 3456);
    t11 = (t10 + 56U);
    t15 = *((char **)t11);
    t16 = (t15 + 56U);
    t18 = *((char **)t16);
    memcpy(t18, t5, 4U);
    xsi_driver_first_trans_fast_port(t10);
    goto LAB8;

LAB26:;
LAB27:    xsi_size_not_matching(4U, t36, 0);
    goto LAB28;

LAB29:    xsi_size_not_matching(4U, t36, 0);
    goto LAB30;

LAB31:    xsi_size_not_matching(4U, t36, 0);
    goto LAB32;

LAB33:    xsi_size_not_matching(4U, t36, 0);
    goto LAB34;

LAB35:    xsi_size_not_matching(4U, t36, 0);
    goto LAB36;

LAB37:    xsi_size_not_matching(4U, t36, 0);
    goto LAB38;

LAB39:    xsi_size_not_matching(4U, t43, 0);
    goto LAB40;

LAB41:    xsi_size_not_matching(4U, t43, 0);
    goto LAB42;

}


extern void work_a_0328778702_3212880686_init()
{
	static char *pe[] = {(void *)work_a_0328778702_3212880686_p_0};
	xsi_register_didat("work_a_0328778702_3212880686", "isim/p2_tb_isim_beh.exe.sim/work/a_0328778702_3212880686.didat");
	xsi_register_executes(pe);
}
