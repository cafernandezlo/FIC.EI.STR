/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0xc3576ebc */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static const char *ng0 = "//windows/usuarios/NDisco/ins/francisco.cedron/STR/p3/p3.vhd";



static void work_a_0082040717_3212880686_p_0(char *t0)
{
    unsigned char t1;
    char *t2;
    char *t3;
    unsigned char t4;
    unsigned char t5;
    unsigned char t6;
    char *t7;
    char *t8;
    unsigned char t9;
    char *t10;
    char *t11;
    int t12;
    char *t13;
    int t14;
    int t15;
    unsigned int t16;
    unsigned int t17;
    unsigned int t18;
    static char *nl0[] = {&&LAB9, &&LAB10, &&LAB11, &&LAB12, &&LAB13, &&LAB14, &&LAB15, &&LAB16};

LAB0:    xsi_set_current_line(66, ng0);
    t2 = (t0 + 1032U);
    t3 = *((char **)t2);
    t4 = *((unsigned char *)t3);
    t5 = (t4 == (unsigned char)3);
    if (t5 == 1)
        goto LAB5;

LAB6:    t1 = (unsigned char)0;

LAB7:    if (t1 != 0)
        goto LAB2;

LAB4:
LAB3:    t2 = (t0 + 3952);
    *((int *)t2) = 1;

LAB1:    return;
LAB2:    xsi_set_current_line(67, ng0);
    t7 = (t0 + 1192U);
    t8 = *((char **)t7);
    t9 = *((unsigned char *)t8);
    t7 = (char *)((nl0) + t9);
    goto **((char **)t7);

LAB5:    t2 = (t0 + 992U);
    t6 = xsi_signal_has_event(t2);
    t1 = t6;
    goto LAB7;

LAB8:    xsi_set_current_line(80, ng0);
    t2 = (t0 + 2288U);
    t3 = *((char **)t2);
    t12 = *((int *)t3);
    t2 = (t0 + 4096);
    t7 = (t2 + 56U);
    t8 = *((char **)t7);
    t10 = (t8 + 56U);
    t11 = *((char **)t10);
    *((int *)t11) = t12;
    xsi_driver_first_trans_fast_port(t2);
    xsi_set_current_line(81, ng0);
    t2 = (t0 + 2408U);
    t3 = *((char **)t2);
    t12 = *((int *)t3);
    t2 = (t0 + 4160);
    t7 = (t2 + 56U);
    t8 = *((char **)t7);
    t10 = (t8 + 56U);
    t11 = *((char **)t10);
    *((int *)t11) = t12;
    xsi_driver_first_trans_fast_port(t2);
    goto LAB3;

LAB9:    xsi_set_current_line(68, ng0);
    t10 = (t0 + 1352U);
    t11 = *((char **)t10);
    t12 = *((int *)t11);
    t10 = (t0 + 2288U);
    t13 = *((char **)t10);
    t10 = (t13 + 0);
    *((int *)t10) = t12;
    goto LAB8;

LAB10:    xsi_set_current_line(69, ng0);
    t2 = (t0 + 1352U);
    t3 = *((char **)t2);
    t12 = *((int *)t3);
    t2 = (t0 + 2408U);
    t7 = *((char **)t2);
    t2 = (t7 + 0);
    *((int *)t2) = t12;
    goto LAB8;

LAB11:    xsi_set_current_line(70, ng0);
    t2 = (t0 + 2288U);
    t3 = *((char **)t2);
    t12 = *((int *)t3);
    t2 = (t0 + 2408U);
    t7 = *((char **)t2);
    t14 = *((int *)t7);
    t15 = (t12 + t14);
    t2 = (t0 + 2288U);
    t8 = *((char **)t2);
    t2 = (t8 + 0);
    *((int *)t2) = t15;
    goto LAB8;

LAB12:    xsi_set_current_line(71, ng0);
    t2 = (t0 + 2288U);
    t3 = *((char **)t2);
    t12 = *((int *)t3);
    t2 = (t0 + 2408U);
    t7 = *((char **)t2);
    t14 = *((int *)t7);
    t15 = (t12 - t14);
    t2 = (t0 + 2288U);
    t8 = *((char **)t2);
    t2 = (t8 + 0);
    *((int *)t2) = t15;
    goto LAB8;

LAB13:    xsi_set_current_line(72, ng0);
    t2 = (t0 + 2288U);
    t3 = *((char **)t2);
    t12 = *((int *)t3);
    t2 = (t0 + 2528U);
    t7 = *((char **)t2);
    t2 = (t0 + 1832U);
    t8 = *((char **)t2);
    t14 = *((int *)t8);
    t15 = (t14 - 255);
    t16 = (t15 * -1);
    xsi_vhdl_check_range_of_index(255, 0, -1, t14);
    t17 = (4U * t16);
    t18 = (0 + t17);
    t2 = (t7 + t18);
    *((int *)t2) = t12;
    goto LAB8;

LAB14:    xsi_set_current_line(73, ng0);
    t2 = (t0 + 2408U);
    t3 = *((char **)t2);
    t12 = *((int *)t3);
    t2 = (t0 + 2528U);
    t7 = *((char **)t2);
    t2 = (t0 + 1832U);
    t8 = *((char **)t2);
    t14 = *((int *)t8);
    t15 = (t14 - 255);
    t16 = (t15 * -1);
    xsi_vhdl_check_range_of_index(255, 0, -1, t14);
    t17 = (4U * t16);
    t18 = (0 + t17);
    t2 = (t7 + t18);
    *((int *)t2) = t12;
    goto LAB8;

LAB15:    xsi_set_current_line(74, ng0);
    t2 = (t0 + 2288U);
    t3 = *((char **)t2);
    t12 = *((int *)t3);
    t2 = (t0 + 4032);
    t7 = (t2 + 56U);
    t8 = *((char **)t7);
    t10 = (t8 + 56U);
    t11 = *((char **)t10);
    *((int *)t11) = t12;
    xsi_driver_first_trans_fast_port(t2);
    goto LAB8;

LAB16:    xsi_set_current_line(75, ng0);
    t2 = (t0 + 2288U);
    t3 = *((char **)t2);
    t12 = *((int *)t3);
    t2 = (t0 + 2648U);
    t7 = *((char **)t2);
    t2 = (t7 + 0);
    *((int *)t2) = t12;
    xsi_set_current_line(76, ng0);
    t2 = (t0 + 2408U);
    t3 = *((char **)t2);
    t12 = *((int *)t3);
    t2 = (t0 + 2288U);
    t7 = *((char **)t2);
    t2 = (t7 + 0);
    *((int *)t2) = t12;
    xsi_set_current_line(77, ng0);
    t2 = (t0 + 2648U);
    t3 = *((char **)t2);
    t12 = *((int *)t3);
    t2 = (t0 + 2408U);
    t7 = *((char **)t2);
    t2 = (t7 + 0);
    *((int *)t2) = t12;
    goto LAB8;

LAB17:    xsi_set_current_line(78, ng0);
    goto LAB8;

}


extern void work_a_0082040717_3212880686_init()
{
	static char *pe[] = {(void *)work_a_0082040717_3212880686_p_0};
	xsi_register_didat("work_a_0082040717_3212880686", "isim/p3_tb_isim_beh.exe.sim/work/a_0082040717_3212880686.didat");
	xsi_register_executes(pe);
}
