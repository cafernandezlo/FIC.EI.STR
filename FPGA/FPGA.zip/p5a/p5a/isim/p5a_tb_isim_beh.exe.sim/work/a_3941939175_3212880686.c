/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0xc3576ebc */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static const char *ng0 = "//windows/usuarios/NDisco/ins/francisco.cedron/STR/p5a/p5a/p5a.vhd";
extern char *IEEE_P_2592010699;
extern char *WORK_P_1046274565;
extern char *STD_STANDARD;

unsigned char ieee_p_2592010699_sub_1744673427_503743352(char *, char *, unsigned int , unsigned int );


static void work_a_3941939175_3212880686_p_0(char *t0)
{
    char t26[16];
    char t28[16];
    char *t1;
    unsigned char t2;
    char *t3;
    char *t4;
    char *t5;
    int t6;
    unsigned int t7;
    unsigned int t8;
    unsigned int t9;
    unsigned char t10;
    char *t11;
    int t12;
    unsigned int t13;
    unsigned int t14;
    unsigned int t15;
    unsigned char t16;
    unsigned char t17;
    char *t18;
    char *t19;
    char *t20;
    int t21;
    unsigned int t22;
    unsigned int t23;
    unsigned int t24;
    char *t25;
    char *t27;
    char *t29;
    char *t30;
    int t31;
    unsigned int t32;
    char *t33;

LAB0:    xsi_set_current_line(55, ng0);
    t1 = (t0 + 1152U);
    t2 = xsi_signal_has_event(t1);
    if (t2 != 0)
        goto LAB2;

LAB4:
LAB3:    xsi_set_current_line(59, ng0);
    t1 = (t0 + 992U);
    t2 = ieee_p_2592010699_sub_1744673427_503743352(IEEE_P_2592010699, t1, 0U, 0U);
    if (t2 != 0)
        goto LAB5;

LAB7:
LAB6:    t1 = (t0 + 2952);
    *((int *)t1) = 1;

LAB1:    return;
LAB2:    xsi_set_current_line(56, ng0);
    t3 = (t0 + 1192U);
    t4 = *((char **)t3);
    t3 = (t0 + 1648U);
    t5 = *((char **)t3);
    t3 = (t5 + 0);
    memcpy(t3, t4, 16U);
    goto LAB3;

LAB5:    xsi_set_current_line(60, ng0);
    t3 = (t0 + 1648U);
    t4 = *((char **)t3);
    t6 = (0 - 15);
    t7 = (t6 * -1);
    t8 = (1U * t7);
    t9 = (0 + t8);
    t3 = (t4 + t9);
    t10 = *((unsigned char *)t3);
    t5 = (t0 + 1648U);
    t11 = *((char **)t5);
    t12 = (1 - 15);
    t13 = (t12 * -1);
    t14 = (1U * t13);
    t15 = (0 + t14);
    t5 = (t11 + t15);
    t16 = *((unsigned char *)t5);
    t17 = (t10 ^ t16);
    t18 = (t0 + 1648U);
    t19 = *((char **)t18);
    t18 = ((WORK_P_1046274565) + 1168U);
    t20 = *((char **)t18);
    t21 = *((int *)t20);
    t22 = (15 - t21);
    t23 = (t22 * 1U);
    t24 = (0 + t23);
    t18 = (t19 + t24);
    t27 = ((STD_STANDARD) + 1112);
    t29 = (t28 + 0U);
    t30 = (t29 + 0U);
    *((int *)t30) = 15;
    t30 = (t29 + 4U);
    *((int *)t30) = 1;
    t30 = (t29 + 8U);
    *((int *)t30) = -1;
    t31 = (1 - 15);
    t32 = (t31 * -1);
    t32 = (t32 + 1);
    t30 = (t29 + 12U);
    *((unsigned int *)t30) = t32;
    t25 = xsi_base_array_concat(t25, t26, t27, (char)99, t17, (char)97, t18, t28, (char)101);
    t30 = (t0 + 1648U);
    t33 = *((char **)t30);
    t30 = (t33 + 0);
    t32 = (1U + 15U);
    memcpy(t30, t25, t32);
    xsi_set_current_line(62, ng0);
    t1 = (t0 + 1648U);
    t3 = *((char **)t1);
    t1 = (t0 + 3032);
    t4 = (t1 + 56U);
    t5 = *((char **)t4);
    t11 = (t5 + 56U);
    t18 = *((char **)t11);
    memcpy(t18, t3, 16U);
    xsi_driver_first_trans_fast_port(t1);
    goto LAB6;

}


extern void work_a_3941939175_3212880686_init()
{
	static char *pe[] = {(void *)work_a_3941939175_3212880686_p_0};
	xsi_register_didat("work_a_3941939175_3212880686", "isim/p5a_tb_isim_beh.exe.sim/work/a_3941939175_3212880686.didat");
	xsi_register_executes(pe);
}
