/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0xc3576ebc */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static const char *ng0 = "//windows/usuarios/NDisco/ins/francisco.cedron/STR/p4/p4/p4_tb.vhd";



static void work_a_3245659458_2372691052_p_0(char *t0)
{
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    int64 t7;
    int64 t8;

LAB0:    t1 = (t0 + 3872U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(100, ng0);
    t2 = (t0 + 4504);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    *((unsigned char *)t6) = (unsigned char)2;
    xsi_driver_first_trans_fast(t2);
    xsi_set_current_line(101, ng0);
    t2 = (t0 + 2768U);
    t3 = *((char **)t2);
    t7 = *((int64 *)t3);
    t8 = (t7 / 2);
    t2 = (t0 + 3680);
    xsi_process_wait(t2, t8);

LAB6:    *((char **)t1) = &&LAB7;

LAB1:    return;
LAB4:    xsi_set_current_line(102, ng0);
    t2 = (t0 + 4504);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    *((unsigned char *)t6) = (unsigned char)3;
    xsi_driver_first_trans_fast(t2);
    xsi_set_current_line(103, ng0);
    t2 = (t0 + 2768U);
    t3 = *((char **)t2);
    t7 = *((int64 *)t3);
    t8 = (t7 / 2);
    t2 = (t0 + 3680);
    xsi_process_wait(t2, t8);

LAB10:    *((char **)t1) = &&LAB11;
    goto LAB1;

LAB5:    goto LAB4;

LAB7:    goto LAB5;

LAB8:    goto LAB2;

LAB9:    goto LAB8;

LAB11:    goto LAB9;

}

static void work_a_3245659458_2372691052_p_1(char *t0)
{
    char *t1;
    char *t2;
    int64 t3;
    char *t4;
    unsigned char t5;
    char *t6;
    char *t7;
    char *t8;
    char *t9;
    int64 t10;
    char *t11;
    int64 t12;
    int64 t13;

LAB0:    t1 = (t0 + 4120U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(112, ng0);
    t3 = (100 * 1000LL);
    t2 = (t0 + 3928);
    xsi_process_wait(t2, t3);

LAB6:    *((char **)t1) = &&LAB7;

LAB1:    return;
LAB4:    xsi_set_current_line(114, ng0);
    t2 = (t0 + 2888U);
    t4 = *((char **)t2);
    t5 = *((unsigned char *)t4);
    if (t5 != 0)
        goto LAB8;

LAB10:    xsi_set_current_line(160, ng0);
    t2 = xsi_get_transient_memory(4U);
    memset(t2, 0, 4U);
    t4 = t2;
    *((unsigned char *)t4) = (unsigned char)0;
    t4 = (t4 + 1U);
    *((unsigned char *)t4) = (unsigned char)1;
    t4 = (t4 + 1U);
    *((unsigned char *)t4) = (unsigned char)0;
    t4 = (t4 + 1U);
    *((unsigned char *)t4) = (unsigned char)2;
    t6 = (t0 + 4760);
    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t9 = (t8 + 56U);
    t11 = *((char **)t9);
    memcpy(t11, t2, 4U);
    xsi_driver_first_trans_fast(t6);
    xsi_set_current_line(161, ng0);
    t2 = (t0 + 2768U);
    t4 = *((char **)t2);
    t3 = *((int64 *)t4);
    t2 = (t0 + 3928);
    xsi_process_wait(t2, t3);

LAB45:    *((char **)t1) = &&LAB46;
    goto LAB1;

LAB5:    goto LAB4;

LAB7:    goto LAB5;

LAB8:    xsi_set_current_line(118, ng0);
    t2 = (t0 + 4568);
    t6 = (t2 + 56U);
    t7 = *((char **)t6);
    t8 = (t7 + 56U);
    t9 = *((char **)t8);
    *((unsigned char *)t9) = (unsigned char)1;
    xsi_driver_first_trans_fast(t2);
    xsi_set_current_line(119, ng0);
    t2 = (t0 + 2768U);
    t4 = *((char **)t2);
    t3 = *((int64 *)t4);
    t2 = (t0 + 3928);
    xsi_process_wait(t2, t3);

LAB13:    *((char **)t1) = &&LAB14;
    goto LAB1;

LAB9:    xsi_set_current_line(171, ng0);

LAB57:    *((char **)t1) = &&LAB58;
    goto LAB1;

LAB11:    xsi_set_current_line(123, ng0);
    t2 = (t0 + 4632);
    t4 = (t2 + 56U);
    t6 = *((char **)t4);
    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    *((unsigned char *)t8) = (unsigned char)1;
    xsi_driver_first_trans_fast(t2);
    xsi_set_current_line(124, ng0);
    t2 = (t0 + 2768U);
    t4 = *((char **)t2);
    t3 = *((int64 *)t4);
    t2 = (t0 + 3928);
    xsi_process_wait(t2, t3);

LAB17:    *((char **)t1) = &&LAB18;
    goto LAB1;

LAB12:    goto LAB11;

LAB14:    goto LAB12;

LAB15:    xsi_set_current_line(128, ng0);
    t2 = (t0 + 4568);
    t4 = (t2 + 56U);
    t6 = *((char **)t4);
    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    *((unsigned char *)t8) = (unsigned char)0;
    xsi_driver_first_trans_fast(t2);
    xsi_set_current_line(129, ng0);
    t2 = (t0 + 2768U);
    t4 = *((char **)t2);
    t3 = *((int64 *)t4);
    t10 = (2 * t3);
    t2 = (t0 + 3928);
    xsi_process_wait(t2, t10);

LAB21:    *((char **)t1) = &&LAB22;
    goto LAB1;

LAB16:    goto LAB15;

LAB18:    goto LAB16;

LAB19:    xsi_set_current_line(133, ng0);
    t2 = (t0 + 4696);
    t4 = (t2 + 56U);
    t6 = *((char **)t4);
    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    *((unsigned char *)t8) = (unsigned char)1;
    xsi_driver_first_trans_delta(t2, 0U, 1, 0LL);
    xsi_set_current_line(134, ng0);
    t2 = (t0 + 2768U);
    t4 = *((char **)t2);
    t3 = *((int64 *)t4);
    t2 = (t0 + 3928);
    xsi_process_wait(t2, t3);

LAB25:    *((char **)t1) = &&LAB26;
    goto LAB1;

LAB20:    goto LAB19;

LAB22:    goto LAB20;

LAB23:    xsi_set_current_line(138, ng0);
    t2 = xsi_get_transient_memory(2U);
    memset(t2, 0, 2U);
    t4 = t2;
    *((unsigned char *)t4) = (unsigned char)1;
    t4 = (t4 + 1U);
    *((unsigned char *)t4) = (unsigned char)1;
    t6 = (t0 + 4696);
    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t9 = (t8 + 56U);
    t11 = *((char **)t9);
    memcpy(t11, t2, 2U);
    xsi_driver_first_trans_fast(t6);
    xsi_set_current_line(139, ng0);
    t2 = (t0 + 4568);
    t4 = (t2 + 56U);
    t6 = *((char **)t4);
    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    *((unsigned char *)t8) = (unsigned char)1;
    xsi_driver_first_trans_fast(t2);
    xsi_set_current_line(140, ng0);
    t2 = (t0 + 4632);
    t4 = (t2 + 56U);
    t6 = *((char **)t4);
    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    *((unsigned char *)t8) = (unsigned char)0;
    xsi_driver_first_trans_fast(t2);
    xsi_set_current_line(141, ng0);
    t2 = (t0 + 2768U);
    t4 = *((char **)t2);
    t3 = *((int64 *)t4);
    t2 = (t0 + 3928);
    xsi_process_wait(t2, t3);

LAB29:    *((char **)t1) = &&LAB30;
    goto LAB1;

LAB24:    goto LAB23;

LAB26:    goto LAB24;

LAB27:    xsi_set_current_line(145, ng0);
    t2 = xsi_get_transient_memory(2U);
    memset(t2, 0, 2U);
    t4 = t2;
    *((unsigned char *)t4) = (unsigned char)0;
    t4 = (t4 + 1U);
    *((unsigned char *)t4) = (unsigned char)0;
    t6 = (t0 + 4696);
    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t9 = (t8 + 56U);
    t11 = *((char **)t9);
    memcpy(t11, t2, 2U);
    xsi_driver_first_trans_fast(t6);
    xsi_set_current_line(146, ng0);
    t2 = (t0 + 4568);
    t4 = (t2 + 56U);
    t6 = *((char **)t4);
    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    *((unsigned char *)t8) = (unsigned char)0;
    xsi_driver_first_trans_fast(t2);
    xsi_set_current_line(147, ng0);
    t2 = (t0 + 4632);
    t4 = (t2 + 56U);
    t6 = *((char **)t4);
    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    *((unsigned char *)t8) = (unsigned char)1;
    xsi_driver_first_trans_fast(t2);
    xsi_set_current_line(148, ng0);
    t2 = (t0 + 2768U);
    t4 = *((char **)t2);
    t3 = *((int64 *)t4);
    t2 = (t0 + 2768U);
    t6 = *((char **)t2);
    t10 = *((int64 *)t6);
    t12 = (t10 / 2);
    t13 = (t3 + t12);
    t2 = (t0 + 3928);
    xsi_process_wait(t2, t13);

LAB33:    *((char **)t1) = &&LAB34;
    goto LAB1;

LAB28:    goto LAB27;

LAB30:    goto LAB28;

LAB31:    xsi_set_current_line(153, ng0);
    t3 = (1 * 1000LL);
    t2 = (t0 + 3928);
    xsi_process_wait(t2, t3);

LAB37:    *((char **)t1) = &&LAB38;
    goto LAB1;

LAB32:    goto LAB31;

LAB34:    goto LAB32;

LAB35:    xsi_set_current_line(155, ng0);
    t2 = (t0 + 4568);
    t4 = (t2 + 56U);
    t6 = *((char **)t4);
    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    *((unsigned char *)t8) = (unsigned char)1;
    xsi_driver_first_trans_fast(t2);
    xsi_set_current_line(156, ng0);
    t3 = (32 * 1000000000LL);
    t2 = (t0 + 3928);
    xsi_process_wait(t2, t3);

LAB41:    *((char **)t1) = &&LAB42;
    goto LAB1;

LAB36:    goto LAB35;

LAB38:    goto LAB36;

LAB39:    goto LAB9;

LAB40:    goto LAB39;

LAB42:    goto LAB40;

LAB43:    xsi_set_current_line(163, ng0);
    t2 = xsi_get_transient_memory(4U);
    memset(t2, 0, 4U);
    t4 = t2;
    *((unsigned char *)t4) = (unsigned char)0;
    t4 = (t4 + 1U);
    *((unsigned char *)t4) = (unsigned char)1;
    t4 = (t4 + 1U);
    *((unsigned char *)t4) = (unsigned char)1;
    t4 = (t4 + 1U);
    *((unsigned char *)t4) = (unsigned char)0;
    t6 = (t0 + 4760);
    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t9 = (t8 + 56U);
    t11 = *((char **)t9);
    memcpy(t11, t2, 4U);
    xsi_driver_first_trans_fast(t6);
    xsi_set_current_line(164, ng0);
    t2 = (t0 + 2768U);
    t4 = *((char **)t2);
    t3 = *((int64 *)t4);
    t2 = (t0 + 3928);
    xsi_process_wait(t2, t3);

LAB49:    *((char **)t1) = &&LAB50;
    goto LAB1;

LAB44:    goto LAB43;

LAB46:    goto LAB44;

LAB47:    xsi_set_current_line(166, ng0);
    t2 = xsi_get_transient_memory(4U);
    memset(t2, 0, 4U);
    t4 = t2;
    *((unsigned char *)t4) = (unsigned char)2;
    t4 = (t4 + 1U);
    *((unsigned char *)t4) = (unsigned char)0;
    t4 = (t4 + 1U);
    *((unsigned char *)t4) = (unsigned char)2;
    t4 = (t4 + 1U);
    *((unsigned char *)t4) = (unsigned char)0;
    t6 = (t0 + 4760);
    t7 = (t6 + 56U);
    t8 = *((char **)t7);
    t9 = (t8 + 56U);
    t11 = *((char **)t9);
    memcpy(t11, t2, 4U);
    xsi_driver_first_trans_fast(t6);
    xsi_set_current_line(167, ng0);
    t2 = (t0 + 2768U);
    t4 = *((char **)t2);
    t3 = *((int64 *)t4);
    t2 = (t0 + 3928);
    xsi_process_wait(t2, t3);

LAB53:    *((char **)t1) = &&LAB54;
    goto LAB1;

LAB48:    goto LAB47;

LAB50:    goto LAB48;

LAB51:    goto LAB9;

LAB52:    goto LAB51;

LAB54:    goto LAB52;

LAB55:    goto LAB2;

LAB56:    goto LAB55;

LAB58:    goto LAB56;

}


extern void work_a_3245659458_2372691052_init()
{
	static char *pe[] = {(void *)work_a_3245659458_2372691052_p_0,(void *)work_a_3245659458_2372691052_p_1};
	xsi_register_didat("work_a_3245659458_2372691052", "isim/p4_tb_isim_beh.exe.sim/work/a_3245659458_2372691052.didat");
	xsi_register_executes(pe);
}
