/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0xc3576ebc */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
extern char *IEEE_P_2592010699;
static const char *ng1 = "Function airbag_frontal_acomp ended without a return statement";
static const char *ng2 = "//windows/usuarios/NDisco/ins/francisco.cedron/STR/p4/p4/p4.vhd";

unsigned char ieee_p_2592010699_sub_1744673427_503743352(char *, char *, unsigned int , unsigned int );


unsigned char work_a_1619180100_sub_1303381377_462349738(char *t1, unsigned char t2, char *t3)
{
    char t4[128];
    char t5[24];
    char t6[16];
    char t13[8];
    unsigned char t0;
    char *t7;
    char *t8;
    int t9;
    unsigned int t10;
    char *t11;
    char *t12;
    char *t14;
    char *t15;
    char *t16;
    char *t17;
    unsigned char t18;
    char *t19;
    unsigned char t20;
    int t21;
    int t22;
    int t23;
    unsigned int t24;
    unsigned int t25;

LAB0:    t7 = (t6 + 0U);
    t8 = (t7 + 0U);
    *((int *)t8) = 0;
    t8 = (t7 + 4U);
    *((int *)t8) = 1;
    t8 = (t7 + 8U);
    *((int *)t8) = 1;
    t9 = (1 - 0);
    t10 = (t9 * 1);
    t10 = (t10 + 1);
    t8 = (t7 + 12U);
    *((unsigned int *)t8) = t10;
    t8 = (t4 + 4U);
    t11 = ((IEEE_P_2592010699) + 3320);
    t12 = (t8 + 88U);
    *((char **)t12) = t11;
    t14 = (t8 + 56U);
    *((char **)t14) = t13;
    *((unsigned char *)t13) = (unsigned char)2;
    t15 = (t8 + 80U);
    *((unsigned int *)t15) = 1U;
    t16 = (t5 + 4U);
    *((unsigned char *)t16) = t2;
    t17 = (t5 + 5U);
    t18 = (t3 != 0);
    if (t18 == 1)
        goto LAB3;

LAB2:    t19 = (t5 + 13U);
    *((char **)t19) = t6;
    t20 = (t2 == (unsigned char)1);
    if (t20 != 0)
        goto LAB4;

LAB6:
LAB5:    t9 = (2U - 1);
    t21 = 0;
    t22 = t9;

LAB8:    if (t21 <= t22)
        goto LAB9;

LAB11:    t0 = (unsigned char)2;

LAB1:    return t0;
LAB3:    *((char **)t17) = t3;
    goto LAB2;

LAB4:    t0 = (unsigned char)3;
    goto LAB1;

LAB7:    goto LAB5;

LAB9:    t23 = (t21 - 0);
    t10 = (t23 * 1);
    xsi_vhdl_check_range_of_index(0, 1, 1, t21);
    t24 = (1U * t10);
    t25 = (0 + t24);
    t7 = (t3 + t25);
    t18 = *((unsigned char *)t7);
    t20 = (t18 == (unsigned char)1);
    if (t20 != 0)
        goto LAB12;

LAB14:
LAB13:
LAB10:    if (t21 == t22)
        goto LAB11;

LAB16:    t9 = (t21 + 1);
    t21 = t9;
    goto LAB8;

LAB12:    t0 = (unsigned char)3;
    goto LAB1;

LAB15:    goto LAB13;

LAB17:;
}

unsigned char work_a_1619180100_sub_589334719_462349738(char *t1, unsigned char t2, char *t3, unsigned char t4)
{
    char t5[128];
    char t6[24];
    char t7[16];
    char t14[8];
    unsigned char t0;
    char *t8;
    char *t9;
    int t10;
    unsigned int t11;
    char *t12;
    char *t13;
    char *t15;
    char *t16;
    char *t17;
    char *t18;
    unsigned char t19;
    char *t20;
    char *t21;
    unsigned char t22;

LAB0:    t8 = (t7 + 0U);
    t9 = (t8 + 0U);
    *((int *)t9) = 0;
    t9 = (t8 + 4U);
    *((int *)t9) = 1;
    t9 = (t8 + 8U);
    *((int *)t9) = 1;
    t10 = (1 - 0);
    t11 = (t10 * 1);
    t11 = (t11 + 1);
    t9 = (t8 + 12U);
    *((unsigned int *)t9) = t11;
    t9 = (t5 + 4U);
    t12 = ((IEEE_P_2592010699) + 3320);
    t13 = (t9 + 88U);
    *((char **)t13) = t12;
    t15 = (t9 + 56U);
    *((char **)t15) = t14;
    *((unsigned char *)t14) = (unsigned char)2;
    t16 = (t9 + 80U);
    *((unsigned int *)t16) = 1U;
    t17 = (t6 + 4U);
    *((unsigned char *)t17) = t2;
    t18 = (t6 + 5U);
    t19 = (t3 != 0);
    if (t19 == 1)
        goto LAB3;

LAB2:    t20 = (t6 + 13U);
    *((char **)t20) = t7;
    t21 = (t6 + 21U);
    *((unsigned char *)t21) = t4;
    t22 = (t4 == (unsigned char)0);
    if (t22 != 0)
        goto LAB4;

LAB6:    t19 = work_a_1619180100_sub_1303381377_462349738(t1, t2, t3);
    t0 = t19;

LAB1:    return t0;
LAB3:    *((char **)t18) = t3;
    goto LAB2;

LAB4:    t0 = (unsigned char)2;
    goto LAB1;

LAB5:    xsi_error(ng1);
    t0 = 0;
    goto LAB1;

LAB7:    goto LAB5;

LAB8:    goto LAB5;

}

unsigned char work_a_1619180100_sub_809066843_462349738(char *t1, char *t2)
{
    char t3[128];
    char t4[24];
    char t5[16];
    char t12[8];
    unsigned char t0;
    char *t6;
    char *t7;
    int t8;
    unsigned int t9;
    char *t10;
    char *t11;
    char *t13;
    char *t14;
    char *t15;
    unsigned char t16;
    char *t17;
    int t18;
    int t19;
    int t20;
    int t21;
    unsigned int t22;
    unsigned int t23;
    char *t24;
    unsigned char t25;
    unsigned char t26;

LAB0:    t6 = (t5 + 0U);
    t7 = (t6 + 0U);
    *((int *)t7) = 0;
    t7 = (t6 + 4U);
    *((int *)t7) = 1;
    t7 = (t6 + 8U);
    *((int *)t7) = 1;
    t8 = (1 - 0);
    t9 = (t8 * 1);
    t9 = (t9 + 1);
    t7 = (t6 + 12U);
    *((unsigned int *)t7) = t9;
    t7 = (t3 + 4U);
    t10 = ((IEEE_P_2592010699) + 3320);
    t11 = (t7 + 88U);
    *((char **)t11) = t10;
    t13 = (t7 + 56U);
    *((char **)t13) = t12;
    *((unsigned char *)t12) = (unsigned char)2;
    t14 = (t7 + 80U);
    *((unsigned int *)t14) = 1U;
    t15 = (t4 + 4U);
    t16 = (t2 != 0);
    if (t16 == 1)
        goto LAB3;

LAB2:    t17 = (t4 + 12U);
    *((char **)t17) = t5;
    t18 = (2U - 1);
    t19 = 0;
    t20 = t18;

LAB4:    if (t19 <= t20)
        goto LAB5;

LAB7:    t0 = (unsigned char)2;

LAB1:    return t0;
LAB3:    *((char **)t15) = t2;
    goto LAB2;

LAB5:    t21 = (t19 - 0);
    t9 = (t21 * 1);
    xsi_vhdl_check_range_of_index(0, 1, 1, t19);
    t22 = (1U * t9);
    t23 = (0 + t22);
    t24 = (t2 + t23);
    t25 = *((unsigned char *)t24);
    t26 = (t25 == (unsigned char)1);
    if (t26 != 0)
        goto LAB8;

LAB10:
LAB9:
LAB6:    if (t19 == t20)
        goto LAB7;

LAB12:    t8 = (t19 + 1);
    t19 = t8;
    goto LAB4;

LAB8:    t0 = (unsigned char)3;
    goto LAB1;

LAB11:    goto LAB9;

LAB13:;
}

char *work_a_1619180100_sub_2761370939_462349738(char *t1, char *t2, char *t3)
{
    char t4[128];
    char t5[24];
    char t6[16];
    char t11[16];
    char t16[8];
    char *t0;
    char *t7;
    char *t8;
    int t9;
    unsigned int t10;
    char *t12;
    int t13;
    char *t14;
    char *t15;
    char *t17;
    char *t18;
    char *t19;
    char *t20;
    unsigned char t21;
    char *t22;
    int t23;
    int t24;
    int t25;
    unsigned int t26;
    unsigned int t27;
    char *t28;
    unsigned char t29;
    unsigned char t30;
    char *t31;
    char *t32;
    int t33;
    char *t34;
    int t35;
    int t36;
    unsigned int t37;
    char *t38;
    int t39;
    unsigned int t40;
    unsigned int t41;
    char *t42;

LAB0:    t7 = (t6 + 0U);
    t8 = (t7 + 0U);
    *((int *)t8) = 0;
    t8 = (t7 + 4U);
    *((int *)t8) = 3;
    t8 = (t7 + 8U);
    *((int *)t8) = 1;
    t9 = (3 - 0);
    t10 = (t9 * 1);
    t10 = (t10 + 1);
    t8 = (t7 + 12U);
    *((unsigned int *)t8) = t10;
    t8 = (t11 + 0U);
    t12 = (t8 + 0U);
    *((int *)t12) = 3;
    t12 = (t8 + 4U);
    *((int *)t12) = 0;
    t12 = (t8 + 8U);
    *((int *)t12) = -1;
    t13 = (0 - 3);
    t10 = (t13 * -1);
    t10 = (t10 + 1);
    t12 = (t8 + 12U);
    *((unsigned int *)t12) = t10;
    t12 = (t4 + 4U);
    t14 = ((IEEE_P_2592010699) + 4024);
    t15 = (t12 + 88U);
    *((char **)t15) = t14;
    t17 = (t12 + 56U);
    *((char **)t17) = t16;
    xsi_type_set_default_value(t14, t16, t11);
    t18 = (t12 + 64U);
    *((char **)t18) = t11;
    t19 = (t12 + 80U);
    *((unsigned int *)t19) = 4U;
    t20 = (t5 + 4U);
    t21 = (t3 != 0);
    if (t21 == 1)
        goto LAB3;

LAB2:    t22 = (t5 + 12U);
    *((char **)t22) = t6;
    t23 = 0;
    t24 = 3;

LAB4:    if (t23 <= t24)
        goto LAB5;

LAB7:    t7 = (t12 + 56U);
    t8 = *((char **)t7);
    t7 = (t11 + 12U);
    t10 = *((unsigned int *)t7);
    t10 = (t10 * 1U);
    t0 = xsi_get_transient_memory(t10);
    memcpy(t0, t8, t10);
    t14 = (t11 + 0U);
    t9 = *((int *)t14);
    t15 = (t11 + 4U);
    t13 = *((int *)t15);
    t17 = (t11 + 8U);
    t23 = *((int *)t17);
    t18 = (t2 + 0U);
    t19 = (t18 + 0U);
    *((int *)t19) = t9;
    t19 = (t18 + 4U);
    *((int *)t19) = t13;
    t19 = (t18 + 8U);
    *((int *)t19) = t23;
    t24 = (t13 - t9);
    t26 = (t24 * t23);
    t26 = (t26 + 1);
    t19 = (t18 + 12U);
    *((unsigned int *)t19) = t26;

LAB1:    return t0;
LAB3:    *((char **)t20) = t3;
    goto LAB2;

LAB5:    t25 = (t23 - 0);
    t10 = (t25 * 1);
    xsi_vhdl_check_range_of_index(0, 3, 1, t23);
    t26 = (1U * t10);
    t27 = (0 + t26);
    t28 = (t3 + t27);
    t29 = *((unsigned char *)t28);
    t30 = (t29 == (unsigned char)2);
    if (t30 != 0)
        goto LAB8;

LAB10:    t7 = (t12 + 56U);
    t8 = *((char **)t7);
    t7 = (t11 + 0U);
    t9 = *((int *)t7);
    t14 = (t11 + 8U);
    t13 = *((int *)t14);
    t25 = (t23 - t9);
    t10 = (t25 * t13);
    t15 = (t11 + 4U);
    t33 = *((int *)t15);
    xsi_vhdl_check_range_of_index(t9, t33, t13, t23);
    t26 = (1U * t10);
    t27 = (0 + t26);
    t17 = (t8 + t27);
    *((unsigned char *)t17) = (unsigned char)2;

LAB9:
LAB6:    if (t23 == t24)
        goto LAB7;

LAB11:    t9 = (t23 + 1);
    t23 = t9;
    goto LAB4;

LAB8:    t31 = (t12 + 56U);
    t32 = *((char **)t31);
    t31 = (t11 + 0U);
    t33 = *((int *)t31);
    t34 = (t11 + 8U);
    t35 = *((int *)t34);
    t36 = (t23 - t33);
    t37 = (t36 * t35);
    t38 = (t11 + 4U);
    t39 = *((int *)t38);
    xsi_vhdl_check_range_of_index(t33, t39, t35, t23);
    t40 = (1U * t37);
    t41 = (0 + t40);
    t42 = (t32 + t41);
    *((unsigned char *)t42) = (unsigned char)3;
    goto LAB9;

LAB12:;
}

char *work_a_1619180100_sub_2077091182_462349738(char *t1, char *t2, char *t3)
{
    char t4[128];
    char t5[24];
    char t6[16];
    char t11[16];
    char t16[8];
    char *t0;
    char *t7;
    char *t8;
    int t9;
    unsigned int t10;
    char *t12;
    int t13;
    char *t14;
    char *t15;
    char *t17;
    char *t18;
    char *t19;
    char *t20;
    unsigned char t21;
    char *t22;
    int t23;
    int t24;
    int t25;
    unsigned int t26;
    unsigned int t27;
    char *t28;
    unsigned char t29;
    unsigned char t30;
    char *t31;
    char *t32;
    int t33;
    char *t34;
    int t35;
    int t36;
    unsigned int t37;
    char *t38;
    int t39;
    unsigned int t40;
    unsigned int t41;
    char *t42;

LAB0:    t7 = (t6 + 0U);
    t8 = (t7 + 0U);
    *((int *)t8) = 0;
    t8 = (t7 + 4U);
    *((int *)t8) = 3;
    t8 = (t7 + 8U);
    *((int *)t8) = 1;
    t9 = (3 - 0);
    t10 = (t9 * 1);
    t10 = (t10 + 1);
    t8 = (t7 + 12U);
    *((unsigned int *)t8) = t10;
    t8 = (t11 + 0U);
    t12 = (t8 + 0U);
    *((int *)t12) = 3;
    t12 = (t8 + 4U);
    *((int *)t12) = 0;
    t12 = (t8 + 8U);
    *((int *)t12) = -1;
    t13 = (0 - 3);
    t10 = (t13 * -1);
    t10 = (t10 + 1);
    t12 = (t8 + 12U);
    *((unsigned int *)t12) = t10;
    t12 = (t4 + 4U);
    t14 = ((IEEE_P_2592010699) + 4024);
    t15 = (t12 + 88U);
    *((char **)t15) = t14;
    t17 = (t12 + 56U);
    *((char **)t17) = t16;
    xsi_type_set_default_value(t14, t16, t11);
    t18 = (t12 + 64U);
    *((char **)t18) = t11;
    t19 = (t12 + 80U);
    *((unsigned int *)t19) = 4U;
    t20 = (t5 + 4U);
    t21 = (t3 != 0);
    if (t21 == 1)
        goto LAB3;

LAB2:    t22 = (t5 + 12U);
    *((char **)t22) = t6;
    t23 = 0;
    t24 = 3;

LAB4:    if (t23 <= t24)
        goto LAB5;

LAB7:    t7 = (t12 + 56U);
    t8 = *((char **)t7);
    t7 = (t11 + 12U);
    t10 = *((unsigned int *)t7);
    t10 = (t10 * 1U);
    t0 = xsi_get_transient_memory(t10);
    memcpy(t0, t8, t10);
    t14 = (t11 + 0U);
    t9 = *((int *)t14);
    t15 = (t11 + 4U);
    t13 = *((int *)t15);
    t17 = (t11 + 8U);
    t23 = *((int *)t17);
    t18 = (t2 + 0U);
    t19 = (t18 + 0U);
    *((int *)t19) = t9;
    t19 = (t18 + 4U);
    *((int *)t19) = t13;
    t19 = (t18 + 8U);
    *((int *)t19) = t23;
    t24 = (t13 - t9);
    t26 = (t24 * t23);
    t26 = (t26 + 1);
    t19 = (t18 + 12U);
    *((unsigned int *)t19) = t26;

LAB1:    return t0;
LAB3:    *((char **)t20) = t3;
    goto LAB2;

LAB5:    t25 = (t23 - 0);
    t10 = (t25 * 1);
    xsi_vhdl_check_range_of_index(0, 3, 1, t23);
    t26 = (1U * t10);
    t27 = (0 + t26);
    t28 = (t3 + t27);
    t29 = *((unsigned char *)t28);
    t30 = (t29 == (unsigned char)1);
    if (t30 != 0)
        goto LAB8;

LAB10:    t7 = (t12 + 56U);
    t8 = *((char **)t7);
    t7 = (t11 + 0U);
    t9 = *((int *)t7);
    t14 = (t11 + 8U);
    t13 = *((int *)t14);
    t25 = (t23 - t9);
    t10 = (t25 * t13);
    t15 = (t11 + 4U);
    t33 = *((int *)t15);
    xsi_vhdl_check_range_of_index(t9, t33, t13, t23);
    t26 = (1U * t10);
    t27 = (0 + t26);
    t17 = (t8 + t27);
    *((unsigned char *)t17) = (unsigned char)2;

LAB9:
LAB6:    if (t23 == t24)
        goto LAB7;

LAB11:    t9 = (t23 + 1);
    t23 = t9;
    goto LAB4;

LAB8:    t31 = (t12 + 56U);
    t32 = *((char **)t31);
    t31 = (t11 + 0U);
    t33 = *((int *)t31);
    t34 = (t11 + 8U);
    t35 = *((int *)t34);
    t36 = (t23 - t33);
    t37 = (t36 * t35);
    t38 = (t11 + 4U);
    t39 = *((int *)t38);
    xsi_vhdl_check_range_of_index(t33, t39, t35, t23);
    t40 = (1U * t37);
    t41 = (0 + t40);
    t42 = (t32 + t41);
    *((unsigned char *)t42) = (unsigned char)3;
    goto LAB9;

LAB12:;
}

static void work_a_1619180100_3212880686_p_0(char *t0)
{
    char t12[16];
    char *t1;
    unsigned char t2;
    char *t3;
    char *t4;
    unsigned char t5;
    char *t6;
    unsigned char t7;
    char *t8;
    char *t9;
    char *t10;
    char *t11;
    unsigned int t13;

LAB0:    xsi_set_current_line(145, ng2);
    t1 = (t0 + 992U);
    t2 = ieee_p_2592010699_sub_1744673427_503743352(IEEE_P_2592010699, t1, 0U, 0U);
    if (t2 != 0)
        goto LAB2;

LAB4:
LAB3:    t1 = (t0 + 3952);
    *((int *)t1) = 1;

LAB1:    return;
LAB2:    xsi_set_current_line(147, ng2);
    t3 = (t0 + 1992U);
    t4 = *((char **)t3);
    t5 = *((unsigned char *)t4);
    t3 = (t0 + 2152U);
    t6 = *((char **)t3);
    t7 = work_a_1619180100_sub_1303381377_462349738(t0, t5, t6);
    t3 = (t0 + 4032);
    t8 = (t3 + 56U);
    t9 = *((char **)t8);
    t10 = (t9 + 56U);
    t11 = *((char **)t10);
    *((unsigned char *)t11) = t7;
    xsi_driver_first_trans_fast_port(t3);
    xsi_set_current_line(148, ng2);
    t1 = (t0 + 1992U);
    t3 = *((char **)t1);
    t2 = *((unsigned char *)t3);
    t1 = (t0 + 2152U);
    t4 = *((char **)t1);
    t1 = (t0 + 2312U);
    t6 = *((char **)t1);
    t5 = *((unsigned char *)t6);
    t7 = work_a_1619180100_sub_589334719_462349738(t0, t2, t4, t5);
    t1 = (t0 + 4096);
    t8 = (t1 + 56U);
    t9 = *((char **)t8);
    t10 = (t9 + 56U);
    t11 = *((char **)t10);
    *((unsigned char *)t11) = t7;
    xsi_driver_first_trans_fast_port(t1);
    xsi_set_current_line(149, ng2);
    t1 = (t0 + 2152U);
    t3 = *((char **)t1);
    t2 = work_a_1619180100_sub_809066843_462349738(t0, t3);
    t1 = (t0 + 4160);
    t4 = (t1 + 56U);
    t6 = *((char **)t4);
    t8 = (t6 + 56U);
    t9 = *((char **)t8);
    *((unsigned char *)t9) = t2;
    xsi_driver_first_trans_fast_port(t1);
    xsi_set_current_line(151, ng2);
    t1 = (t0 + 2472U);
    t3 = *((char **)t1);
    t1 = work_a_1619180100_sub_2761370939_462349738(t0, t12, t3);
    t4 = (t12 + 12U);
    t13 = *((unsigned int *)t4);
    t13 = (t13 * 1U);
    t2 = (4U != t13);
    if (t2 == 1)
        goto LAB5;

LAB6:    t6 = (t0 + 4224);
    t8 = (t6 + 56U);
    t9 = *((char **)t8);
    t10 = (t9 + 56U);
    t11 = *((char **)t10);
    memcpy(t11, t1, 4U);
    xsi_driver_first_trans_fast_port(t6);
    xsi_set_current_line(152, ng2);
    t1 = (t0 + 2472U);
    t3 = *((char **)t1);
    t1 = work_a_1619180100_sub_2077091182_462349738(t0, t12, t3);
    t4 = (t12 + 12U);
    t13 = *((unsigned int *)t4);
    t13 = (t13 * 1U);
    t2 = (4U != t13);
    if (t2 == 1)
        goto LAB7;

LAB8:    t6 = (t0 + 4288);
    t8 = (t6 + 56U);
    t9 = *((char **)t8);
    t10 = (t9 + 56U);
    t11 = *((char **)t10);
    memcpy(t11, t1, 4U);
    xsi_driver_first_trans_fast_port(t6);
    goto LAB3;

LAB5:    xsi_size_not_matching(4U, t13, 0);
    goto LAB6;

LAB7:    xsi_size_not_matching(4U, t13, 0);
    goto LAB8;

}


extern void work_a_1619180100_3212880686_init()
{
	static char *pe[] = {(void *)work_a_1619180100_3212880686_p_0};
	static char *se[] = {(void *)work_a_1619180100_sub_1303381377_462349738,(void *)work_a_1619180100_sub_589334719_462349738,(void *)work_a_1619180100_sub_809066843_462349738,(void *)work_a_1619180100_sub_2761370939_462349738,(void *)work_a_1619180100_sub_2077091182_462349738};
	xsi_register_didat("work_a_1619180100_3212880686", "isim/p4_tb_isim_beh.exe.sim/work/a_1619180100_3212880686.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}
