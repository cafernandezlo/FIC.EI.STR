/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0xc3576ebc */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
extern char *STD_STANDARD;
extern char *WORK_P_1046274565;
static const char *ng2 = "//windows/usuarios/NDisco/ins/francisco.cedron/STR/p5b/p5b/p5b.vhd";
extern char *IEEE_P_2592010699;

unsigned char ieee_p_2592010699_sub_1744673427_503743352(char *, char *, unsigned int , unsigned int );


int work_a_3547859746_3212880686_sub_4136932132_3057020925(char *t1, int t2, char *t3)
{
    char t4[128];
    char t5[24];
    char t6[16];
    char t13[8];
    int t0;
    char *t7;
    char *t8;
    int t9;
    unsigned int t10;
    char *t11;
    char *t12;
    char *t14;
    char *t15;
    char *t16;
    char *t17;
    unsigned char t18;
    char *t19;
    char *t20;
    char *t21;
    int t22;
    int t23;
    int t24;
    int t25;
    unsigned char t26;
    int t27;
    char *t28;
    int t29;
    int t30;
    char *t31;
    int t32;
    unsigned int t33;
    unsigned int t34;
    char *t35;
    unsigned char t36;
    unsigned char t37;
    int t38;
    char *t39;
    int t40;
    char *t41;
    int t42;
    int t43;
    unsigned int t44;
    char *t45;
    int t46;
    unsigned int t47;
    unsigned int t48;
    char *t49;
    unsigned char t50;
    unsigned char t51;
    char *t52;
    char *t53;
    int t54;
    int t55;
    char *t56;

LAB0:    t7 = (t6 + 0U);
    t8 = (t7 + 0U);
    *((int *)t8) = 39;
    t8 = (t7 + 4U);
    *((int *)t8) = 0;
    t8 = (t7 + 8U);
    *((int *)t8) = -1;
    t9 = (0 - 39);
    t10 = (t9 * -1);
    t10 = (t10 + 1);
    t8 = (t7 + 12U);
    *((unsigned int *)t8) = t10;
    t8 = (t4 + 4U);
    t11 = ((STD_STANDARD) + 384);
    t12 = (t8 + 88U);
    *((char **)t12) = t11;
    t14 = (t8 + 56U);
    *((char **)t14) = t13;
    *((int *)t13) = 0;
    t15 = (t8 + 80U);
    *((unsigned int *)t15) = 4U;
    t16 = (t5 + 4U);
    *((int *)t16) = t2;
    t17 = (t5 + 8U);
    t18 = (t3 != 0);
    if (t18 == 1)
        goto LAB3;

LAB2:    t19 = (t5 + 16U);
    *((char **)t19) = t6;
    t20 = ((WORK_P_1046274565) + 1168U);
    t21 = *((char **)t20);
    t22 = *((int *)t21);
    t23 = (t22 - t2);
    t24 = 0;
    t25 = t23;

LAB4:    if (t24 <= t25)
        goto LAB5;

LAB7:    t7 = (t8 + 56U);
    t11 = *((char **)t7);
    t9 = *((int *)t11);
    t0 = t9;

LAB1:    return t0;
LAB3:    *((char **)t17) = t3;
    goto LAB2;

LAB5:    t20 = (t6 + 0U);
    t27 = *((int *)t20);
    t28 = (t6 + 8U);
    t29 = *((int *)t28);
    t30 = (t24 - t27);
    t10 = (t30 * t29);
    t31 = (t6 + 4U);
    t32 = *((int *)t31);
    xsi_vhdl_check_range_of_index(t27, t32, t29, t24);
    t33 = (1U * t10);
    t34 = (0 + t33);
    t35 = (t3 + t34);
    t36 = *((unsigned char *)t35);
    t37 = (t36 == (unsigned char)1);
    if (t37 == 1)
        goto LAB11;

LAB12:    t26 = (unsigned char)0;

LAB13:    if (t26 != 0)
        goto LAB8;

LAB10:
LAB9:
LAB6:    if (t24 == t25)
        goto LAB7;

LAB14:    t9 = (t24 + 1);
    t24 = t9;
    goto LAB4;

LAB8:    t52 = (t8 + 56U);
    t53 = *((char **)t52);
    t54 = *((int *)t53);
    t55 = (t54 + 1);
    t52 = (t8 + 56U);
    t56 = *((char **)t52);
    t52 = (t56 + 0);
    *((int *)t52) = t55;
    goto LAB9;

LAB11:    t38 = (t24 + t2);
    t39 = (t6 + 0U);
    t40 = *((int *)t39);
    t41 = (t6 + 8U);
    t42 = *((int *)t41);
    t43 = (t38 - t40);
    t44 = (t43 * t42);
    t45 = (t6 + 4U);
    t46 = *((int *)t45);
    xsi_vhdl_check_range_of_index(t40, t46, t42, t38);
    t47 = (1U * t44);
    t48 = (0 + t47);
    t49 = (t3 + t48);
    t50 = *((unsigned char *)t49);
    t51 = (t50 == (unsigned char)1);
    t26 = t51;
    goto LAB13;

LAB15:;
}

static void work_a_3547859746_3212880686_p_0(char *t0)
{
    char t42[16];
    char t44[16];
    char *t1;
    unsigned char t2;
    char *t3;
    char *t4;
    char *t5;
    int t6;
    unsigned int t7;
    unsigned int t8;
    unsigned int t9;
    unsigned char t10;
    char *t11;
    int t12;
    unsigned int t13;
    unsigned int t14;
    unsigned int t15;
    unsigned char t16;
    unsigned char t17;
    char *t18;
    char *t19;
    int t20;
    unsigned int t21;
    unsigned int t22;
    unsigned int t23;
    unsigned char t24;
    unsigned char t25;
    char *t26;
    char *t27;
    int t28;
    unsigned int t29;
    unsigned int t30;
    unsigned int t31;
    unsigned char t32;
    unsigned char t33;
    char *t34;
    char *t35;
    char *t36;
    int t37;
    unsigned int t38;
    unsigned int t39;
    unsigned int t40;
    char *t41;
    char *t43;
    char *t45;
    char *t46;
    int t47;
    unsigned int t48;
    char *t49;

LAB0:    xsi_set_current_line(66, ng2);
    t1 = (t0 + 1152U);
    t2 = xsi_signal_has_event(t1);
    if (t2 != 0)
        goto LAB2;

LAB4:
LAB3:    xsi_set_current_line(70, ng2);
    t1 = (t0 + 992U);
    t2 = ieee_p_2592010699_sub_1744673427_503743352(IEEE_P_2592010699, t1, 0U, 0U);
    if (t2 != 0)
        goto LAB5;

LAB7:
LAB6:    t1 = (t0 + 3112);
    *((int *)t1) = 1;

LAB1:    return;
LAB2:    xsi_set_current_line(67, ng2);
    t3 = (t0 + 1192U);
    t4 = *((char **)t3);
    t3 = (t0 + 1808U);
    t5 = *((char **)t3);
    t3 = (t5 + 0);
    memcpy(t3, t4, 40U);
    goto LAB3;

LAB5:    xsi_set_current_line(71, ng2);
    t3 = (t0 + 1808U);
    t4 = *((char **)t3);
    t6 = (39 - 39);
    t7 = (t6 * -1);
    t8 = (1U * t7);
    t9 = (0 + t8);
    t3 = (t4 + t9);
    t10 = *((unsigned char *)t3);
    t5 = (t0 + 1808U);
    t11 = *((char **)t5);
    t12 = (37 - 39);
    t13 = (t12 * -1);
    t14 = (1U * t13);
    t15 = (0 + t14);
    t5 = (t11 + t15);
    t16 = *((unsigned char *)t5);
    t17 = (t10 ^ t16);
    t18 = (t0 + 1808U);
    t19 = *((char **)t18);
    t20 = (20 - 39);
    t21 = (t20 * -1);
    t22 = (1U * t21);
    t23 = (0 + t22);
    t18 = (t19 + t23);
    t24 = *((unsigned char *)t18);
    t25 = (((!(t17))) ^ t24);
    t26 = (t0 + 1808U);
    t27 = *((char **)t26);
    t28 = (18 - 39);
    t29 = (t28 * -1);
    t30 = (1U * t29);
    t31 = (0 + t30);
    t26 = (t27 + t31);
    t32 = *((unsigned char *)t26);
    t33 = (((!(t25))) ^ t32);
    t34 = (t0 + 1808U);
    t35 = *((char **)t34);
    t34 = ((WORK_P_1046274565) + 1168U);
    t36 = *((char **)t34);
    t37 = *((int *)t36);
    t38 = (39 - t37);
    t39 = (t38 * 1U);
    t40 = (0 + t39);
    t34 = (t35 + t40);
    t43 = ((STD_STANDARD) + 1112);
    t45 = (t44 + 0U);
    t46 = (t45 + 0U);
    *((int *)t46) = 39;
    t46 = (t45 + 4U);
    *((int *)t46) = 1;
    t46 = (t45 + 8U);
    *((int *)t46) = -1;
    t47 = (1 - 39);
    t48 = (t47 * -1);
    t48 = (t48 + 1);
    t46 = (t45 + 12U);
    *((unsigned int *)t46) = t48;
    t41 = xsi_base_array_concat(t41, t42, t43, (char)99, (!(t33)), (char)97, t34, t44, (char)101);
    t46 = (t0 + 1808U);
    t49 = *((char **)t46);
    t46 = (t49 + 0);
    t48 = (1U + 39U);
    memcpy(t46, t41, t48);
    xsi_set_current_line(73, ng2);
    t1 = (t0 + 1808U);
    t3 = *((char **)t1);
    t1 = (t0 + 3192);
    t4 = (t1 + 56U);
    t5 = *((char **)t4);
    t11 = (t5 + 56U);
    t18 = *((char **)t11);
    memcpy(t18, t3, 40U);
    xsi_driver_first_trans_fast_port(t1);
    xsi_set_current_line(75, ng2);
    t1 = (t0 + 1808U);
    t3 = *((char **)t1);
    t6 = work_a_3547859746_3212880686_sub_4136932132_3057020925(t0, 4, t3);
    t1 = (t0 + 3256);
    t4 = (t1 + 56U);
    t5 = *((char **)t4);
    t11 = (t5 + 56U);
    t18 = *((char **)t11);
    *((int *)t18) = t6;
    xsi_driver_first_trans_fast_port(t1);
    goto LAB6;

}


extern void work_a_3547859746_3212880686_init()
{
	static char *pe[] = {(void *)work_a_3547859746_3212880686_p_0};
	static char *se[] = {(void *)work_a_3547859746_3212880686_sub_4136932132_3057020925};
	xsi_register_didat("work_a_3547859746_3212880686", "isim/p5b_tb_isim_beh.exe.sim/work/a_3547859746_3212880686.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
}
