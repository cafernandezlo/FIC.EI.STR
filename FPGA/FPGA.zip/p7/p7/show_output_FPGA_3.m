close all;
clear all;
clc;

%% Se cargan los archivos
dance = true;
outExtension = 'imfpga';
if (dance)
    inImageChrome = 'chroma_key1.jpg';
    inImageBack   = 'background.jpeg';
    chrome = 'chrome1';
    back   = 'back1';
    montaje = 'montaje1';
else
    inImageChrome = 'chroma_key2.jpg';
    inImageBack   = 'bora_bora.jpg';
    chrome = 'chrome2';
    back   = 'back2';
    montaje = 'montaje2';
end


%% Se procede a recoger las imagenes
try
    rgb = ['r' 'g' 'b'];
    inImageChrome = imread(inImageChrome);
    inImageBack   = imread(inImageBack);
    disp([montaje '_binaria.' outExtension])
im_bin = [montaje '_binaria.' outExtension]; 
sizeOriginal = size(inImageChrome);
    outBIN  = read_out_FPGA([montaje '_binaria.' outExtension], size(inImageChrome));
    tmp = zeros(size(inImageChrome));
    for i = 1: length(rgb)
        disp([montaje '_' rgb(i) '.' outExtension]);
        tmp(:,:,i) = read_out_FPGA([montaje '_' rgb(i) '.' outExtension], size(inImageChrome));
    end
    outRGB = uint8(tmp);
catch
   error('Fallo al leer las imagenes de salida de la fpga'); 
end

%% Se procede a mostrar las imagenes
figure;

subplot(221);
imshow(inImageChrome);
title('Croma');

subplot(222);
imshow(inImageBack);
title('fondo');

subplot(223);
imshow(outBIN*255);
title('resultado de la umbralizacion');

subplot(224);

imshow(outRGB);

% outHSV = rgb2hsv(inImage);
% if (bora)
%     outHSV(:,:,2) = double(inImage(:,:,2))/255 .* double(outBIN);
% else
%     outHSV(:,:,1) = double(240)/360 .* double(outBIN);
%     outHSV(:,:,2) = double(outHSV(:,:,2))/255 .* double(outBIN) + double(outBIN == 1)*0.2;
% end
% 
% imshow(hsv2rgb(outHSV));
title('montaje');