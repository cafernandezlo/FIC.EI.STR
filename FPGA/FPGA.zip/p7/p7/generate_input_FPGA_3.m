close all;
clear all;
clc;

% background.jpeg
% bora_bora.jpg
% chroma_key1.jpg
% chroma_key2.jpg

inImage = 'background.jpeg'

outImage = 'back1';

rgb = ['r' 'g' 'b'];
outExtension = 'imfpga';
tmp = imread(inImage);



for i = 1:length(rgb)
   disp (rgb(i));
   generaEntradaComponentesFPGA(tmp, [outImage '_' rgb(i) '.' outExtension], i);
end


