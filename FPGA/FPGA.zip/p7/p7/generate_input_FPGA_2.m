close all;
clear all;
clc;

%% Se cargan los archivos
fire = false;
if (fire)
    inImage = 'lume';
    inExtension = 'png';
else
    inImage = 'fume';
    inExtension = 'jpg';
end

rgb = ['r' 'g' 'b'];
outExtension = 'imfpga';
tmp = imread([inImage '.' inExtension]);

for i = 1:length(rgb)
   disp (rgb(i));
   generaEntradaComponentesFPGA(tmp, [inImage '_' rgb(i) '.' outExtension], i);
end


