%% La funcion lee la salida que se ha producido en la fpga.
%  La funcion es capaz de saber si el archivo que se le pasa se corresponde
%  con una componente de color o son varias
% Parametros
%      im_bin       : ruta del archivo de salida de la fpga
%      sizeOriginal : tamano de la imagen original

function [outImage] = read_out_FPGA(im_bin, sizeOriginal)

%% Comprobar el numero de parametros que se pasan a la funcion
    if (nargin ~= 2)
        error('read_out_FPGA: solo admite dos parametros');
    end

%% Se lee el fichero que solo contine caracteres
    try
        fid = fopen(im_bin);
        temp = textscan(fid, '%d');
        fclose(fid);
%       size(temp)
%       size(temp{1})
    catch
        error('read_out_FPGA: No se ha podido acceder al archivo');
    end
    
%% se intenta pasar el archivo a una imagen (comprueba si es para una componente o para varias)
    switch size(sizeOriginal, 2)
        case 2
            if (size(temp{1}, 1) == sizeOriginal(1) * sizeOriginal(2))
                outImage = uint8(reshape(temp{1}, sizeOriginal(1), sizeOriginal(2) ));
            else
                sprintf('El tamano tenia que ser %d pero en cambio es %d\n', sizeOriginal(1) * sizeOriginal(2),size(temp{1}, 1));
                error('read_out_FPGA: El archivo no se ajusta al tamano indicado.'),
            end
        case 3
%             disp(size(temp{1}, 1))
%             disp(sizeOriginal(1) * sizeOriginal(2))
%             disp(sizeOriginal(1) * sizeOriginal(2)*sizeOriginal(3))
            if (size(temp{1}, 1) == sizeOriginal(1) * sizeOriginal(2))
                outImage = uint8(reshape(temp{1}, sizeOriginal(1), sizeOriginal(2)));
            elseif (size(temp{1}, 1) == sizeOriginal(1) * sizeOriginal(2)*sizeOriginal(3))
                outImage = uint8(reshape(temp{1}, sizeOriginal(1), sizeOriginal(2), sizeOriginal(3) ));
            else
               sprintf('El tamano tenia que ser %d o %d pero en cambio es %d\n', sizeOriginal(1) * sizeOriginal(2), sizeOriginal(1) * sizeOriginal(2)*sizeOriginal(3),size(temp{1}, 1));
               error('read_out_FPGA: El archivo no se ajusta al tamano indicado!');
            end
        otherwise
            error('read_out_FPGA: El tamano pasado no se corresponde con una imagen');
    end

end