close all;
clear all;
clc;

%% Se cargan los archivos
fire = false;
outExtension = 'imfpga';
if (fire)
    nImage = 'lume';
    outRGB  = 'lume_salida';
    outBIN  = 'lume_binaria';
    inExtension = 'png';
else
    nImage = 'fume';
    outRGB  = 'fume_salida';
    outBIN  = 'fume_binaria';
    inExtension = 'jpg';
end

%% Se procede a recoger las imagenes
try
    rgb = ['r' 'g' 'b'];
    disp([nImage '.' inExtension]);
    inImage = imread([nImage '.' inExtension]);
    disp([outBIN '.' outExtension]);
    outBIN  = read_out_FPGA([outBIN '.' outExtension], size(inImage));
    tmp = zeros(size(inImage));
    for i = 1: length(rgb)
        disp([outRGB '_' rgb(i) '.' outExtension]);
        tmp(:,:,i) = read_out_FPGA([outRGB '_' rgb(i) '.' outExtension], size(inImage));
    end
    outRGB = uint8(tmp);
catch
   error('Fallo al leer las imagenes de salida de la fpga'); 
end

%% Se procede a mostrar las imagenes
figure;

subplot(221);
imshow(inImage);
title('imagen original');

subplot(222);
imshow(outRGB);
title('imagen filtrada de la original');

subplot(223);
imshow(outBIN*255);
title('resultado de la umbralizacion');

subplot(224);

outHSV = rgb2hsv(inImage);
if (fire)
    outHSV(:,:,2) = double(inImage(:,:,2))/255 .* double(outBIN);
else
    outHSV(:,:,1) = double(240)/360 .* double(outBIN);
    outHSV(:,:,2) = double(outHSV(:,:,2))/255 .* double(outBIN) + double(outBIN == 1)*0.2;
end

imshow(hsv2rgb(outHSV));
title('original + umbralizada + hsv');