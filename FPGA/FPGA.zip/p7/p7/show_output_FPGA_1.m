close all;
clear all;
clc;

%% Se cargan los archivos
fire = false;
if (fire)
    inImage = 'lume.png';
    outRGB  = 'lume_salida.imfpga';
    outBIN  = 'lume_binaria.imfpga';
else
    inImage = 'fume.jpg';
    outRGB  = 'fume_salida.imfpga';
    outBIN  = 'fume_binaria.imfpga';
end

%% Se procede a recoger las imagenes
try
    inImage = imread(inImage);
    outRGB  = read_out_FPGA(outRGB, size(inImage));
    outBIN  = read_out_FPGA(outBIN, size(inImage));
catch
   error('Fallo al leer las imagenes de salida de la fpga'); 
end

%% Se procede a mostrar las imagenes
figure;

subplot(221);
imshow(inImage);
title('imagen original');

subplot(222);
imshow(outRGB);
title('imagen filtrada de la original');

subplot(223);
imshow(outBIN*255);
title('resultado de la umbralizacion');

subplot(224);

outHSV = rgb2hsv(inImage);
if (fire)
    outHSV(:,:,2) = double(inImage(:,:,2))/255 .* double(outBIN);
else
    outHSV(:,:,1) = double(240)/360 .* double(outBIN);
    outHSV(:,:,2) = double(outHSV(:,:,2))/255 .* double(outBIN) + double(outBIN == 1)*0.2;
end

imshow(hsv2rgb(outHSV));
title('original + umbralizada + hsv');