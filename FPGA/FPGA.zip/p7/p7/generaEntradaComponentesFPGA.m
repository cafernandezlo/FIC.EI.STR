%% Esta funcion crea un fichero de texto donde cada linea tiene hay un valor de la matriz de de las componentes
%  parametros
%       inImage  : imagen de entrada
%       nfile    : nombre del archivo de salida
%       component: componente que se quiere guardar
function generaEntradaComponentesFPGA(inImage, nfile, component)

    if (nargin ~= 3)
        error('generaEntradaComponentesFPGA: recibe tres parametros de entrada');
    end
    
    if size(inImage, 3) < component
       error('generaEntradaComponetesFPGA: no existe esa componente'); 
    end

    m = [reshape(inImage(:,:,component), 1, size(inImage, 1) * size(inImage, 2))];
    
    try
        fid = fopen(nfile,'w');
        for i=1:length(m)
            fprintf(fid,'%d ',m(i));
            fprintf(fid,'\r\n'); % salto de linea en windows
        end
        fclose(fid);
    catch
        error('generaEntradaComponentesFPGA: no se ha podido guardar el fichero');
    end
end